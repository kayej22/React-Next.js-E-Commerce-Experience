# CPNT-265 Final Project

## Joel Kaye


### Achievements 
-SVG Custom Logo
-Videography Presentation
-React incorporation

-Next.Js incorporation
-Snipcart incorporation


-Project proposal
-To do list via Trello - https://trello.com/b/5YenXACJ/cpnt265-final
-Instructional Video
-Greensock incorporation
